+-------------------------------+
| Cheat Manager v0.3 by SpriteZ |
+-------------------------------+
|     spritez.z@gmail.com       |
+-------------------------------+
Thanks Waninkoko and his WAD Manager

[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- Cheat Manager is an homebrew that allows you to generate GCT file
  form text file.

- Allows you edit text code.

- List txt file on sd card.

- Chaet Codes can be found here : http://www.usbgecko.com/codes/

[ SUPPORTED DEVICES ]:

- SD Card.

[ HOW TO USE ]:

1. Create "cheat_manager" folder in the app folder.
2. Copy boot.dol, icon.png and meta.xml in the folder created in the step 1.
3. Create "txtcodes" folder in root of the SD Card.
4. Create "codes" folder in root of the SD Card.
5. Put text cheat code file in "txtcodes" folder.
6. Run the application with any method to load homebrew.

7. In "File List" status, use [UP][DOWN] Move Cursor, [LEFT][RIGHT] Switch Page, [A] Select File, [Home] Exit.
8. Use [A] Select a text file, enter "Item List" status.
9. In "Item List" status, use [UP][DOWN] Move Cursor, [LEFT][RIGHT] Switch Page, 
   [+][-] (not)Select Item Code, [A] View this code. 
   [B] back "File List" status. [1] Generate GCT File in "codes" folder, [Home] Exit.
   prefix explain: [+] Mark Select.
                   [-] not Select.
                   [!] this code item include comment
                   [?] this code item include variational code, you must edit it before generate gct file.
10. you can use [A] view any code item, and select any code(hex) to edit.
11. In "Item List" status, press [A] enter "code view" status.
12. In "code view" status, use [UP][DOWN] Move Cursor, [LEFT][RIGHT] Switch Page, 
    [A] Edit code(Hex), [B] back "Item List" status. [Home] Exit.



[ NOTES ]:

- Text Code file is ASCII file. this application can not support UTF-8 file.


[ KUDOS & THANKS ]:

- Team Twiizers/devkitPRO -> libogc
- svpe                    -> usbstorage driver
- Waninkoko               -> WAD Manager v1.3
- All my betatesters.
